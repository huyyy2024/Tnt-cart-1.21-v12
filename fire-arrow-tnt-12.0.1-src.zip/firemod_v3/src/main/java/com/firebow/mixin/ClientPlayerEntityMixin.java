package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.BowTrajectoryUtil;
import com.firebow.util.InteractionUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ClientPlayerEntityMixin v11:
 *
 * 1. beforeSync — hook sendMovementPackets() như BOOST-FPS.
 *    Cart retry luôn đi kèm movement packet → anti-cheat safe.
 *
 * 2. Bow release detection — học từ BOOST-FPS release_use_item pattern.
 *    Detect ngay khi player thả cung → tính trajectory → đặt rail ngay.
 *    Nhanh hơn nhiều so với đợi arrow bay đến gần.
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Unique private boolean firebow$wasUsingBow = false;
    @Unique private int     firebow$useTimeLeft  = 0;

    // ── beforeSync — anti-cheat pattern ──
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }

    // ── Bow release detection ──
    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        boolean usingBow = self.isUsingItem() &&
                           BowTrajectoryUtil.isHoldingBow(self);

        if (usingBow) {
            // Track thời gian kéo cung
            firebow$wasUsingBow = true;
            firebow$useTimeLeft = self.getItemUseTimeLeft();
        } else if (firebow$wasUsingBow) {
            // Vừa thả cung — trigger ngay như BOOST-FPS release_use_item
            firebow$wasUsingBow = false;
            onBowRelease(self, rt, mc, firebow$useTimeLeft);
            firebow$useTimeLeft = 0;
        }
    }

    @Unique
    private void onBowRelease(ClientPlayerEntity player, FireBowRuntime rt,
                               MinecraftClient mc, int useTimeLeft) {
        if (mc.interactionManager == null) return;

        // Tính trajectory ngay tại lúc thả — trước khi tên được tạo
        BlockPos railPos = BowTrajectoryUtil.predictLanding(player, useTimeLeft);
        if (railPos == null) return;
        if (!InteractionUtil.inReach(player, railPos)) return;

        // Khoảng cách tối thiểu 1 block
        if (player.getEyePos().squaredDistanceTo(
                net.minecraft.util.math.Vec3d.ofCenter(railPos)) < 1.0 * 1.0) return;

        // Check inventory
        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Đặt Rail ngay tại lúc thả cung
        int saved = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = target.railSlot.slot;
        InteractionUtil.placeBelow(mc, railPos);
        player.getInventory().selectedSlot = saved;

        // Lên lịch cart — entityId dùng player ID vì arrow chưa tồn tại
        long ping = 50L;
        try {
            if (mc.getNetworkHandler() != null) {
                var e = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
                if (e != null) ping = e.getLatency();
            }
        } catch (Exception ignored) {}

        int cartDelay = ping > 200 ? 4 : ping > 100 ? 3 : 2;
        // Dùng railPos hashcode làm ID vì arrow chưa tồn tại
        rt.acceptArrow(railPos.hashCode(), railPos, cartDelay);
    }
}
